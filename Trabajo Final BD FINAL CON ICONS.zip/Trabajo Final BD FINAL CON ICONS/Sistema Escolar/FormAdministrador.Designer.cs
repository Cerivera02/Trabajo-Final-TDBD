﻿namespace Sistema_Escolar
{
    partial class FormAdministrador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAdministrador));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPageAlumnos = new System.Windows.Forms.TabPage();
            this.txtBoxCarrera = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtBoxCURP = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.btn_Clear = new System.Windows.Forms.Button();
            this.txtBoxTelefono = new System.Windows.Forms.TextBox();
            this.txtBoxApellidoMaterno = new System.Windows.Forms.TextBox();
            this.txtBoxApellidoPaterno = new System.Windows.Forms.TextBox();
            this.txtBoxNombre = new System.Windows.Forms.TextBox();
            this.lblTelefono = new System.Windows.Forms.Label();
            this.lblApellidoMaterno = new System.Windows.Forms.Label();
            this.lblApelidoPaterno = new System.Windows.Forms.Label();
            this.lblNombre = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.comboBoxTipoUser = new System.Windows.Forms.ComboBox();
            this.btnAgregarMaestros = new System.Windows.Forms.Button();
            this.btnLimpiarMaestros = new System.Windows.Forms.Button();
            this.txtBoxPassword = new System.Windows.Forms.TextBox();
            this.txtBoxUsername = new System.Windows.Forms.TextBox();
            this.lblTipoUser = new System.Windows.Forms.Label();
            this.lblPassword = new System.Windows.Forms.Label();
            this.lblUser = new System.Windows.Forms.Label();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.dataGridAlumnos = new System.Windows.Forms.DataGridView();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.dataGridMaestros = new System.Windows.Forms.DataGridView();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.dgv2 = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.nuevoValor_Tbx = new System.Windows.Forms.TextBox();
            this.NoControlParaEditar_Tbx = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Editar_datos_Cbx = new System.Windows.Forms.ComboBox();
            this.Editar_Lbl_ = new System.Windows.Forms.Label();
            this.Editar_Btn = new System.Windows.Forms.Button();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.Eliminar_Btn = new System.Windows.Forms.Button();
            this.Titulo_Lbl = new System.Windows.Forms.Label();
            this.noControl_Lbl = new System.Windows.Forms.Label();
            this.noControl_Tbx = new System.Windows.Forms.TextBox();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.dgv3 = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPageAlumnos.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridAlumnos)).BeginInit();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridMaestros)).BeginInit();
            this.tabPage10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv3)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPageAlumnos);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(5, 5);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(715, 311);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPageAlumnos
            // 
            this.tabPageAlumnos.Controls.Add(this.txtBoxCarrera);
            this.tabPageAlumnos.Controls.Add(this.label4);
            this.tabPageAlumnos.Controls.Add(this.txtBoxCURP);
            this.tabPageAlumnos.Controls.Add(this.label3);
            this.tabPageAlumnos.Controls.Add(this.btnAgregar);
            this.tabPageAlumnos.Controls.Add(this.btn_Clear);
            this.tabPageAlumnos.Controls.Add(this.txtBoxTelefono);
            this.tabPageAlumnos.Controls.Add(this.txtBoxApellidoMaterno);
            this.tabPageAlumnos.Controls.Add(this.txtBoxApellidoPaterno);
            this.tabPageAlumnos.Controls.Add(this.txtBoxNombre);
            this.tabPageAlumnos.Controls.Add(this.lblTelefono);
            this.tabPageAlumnos.Controls.Add(this.lblApellidoMaterno);
            this.tabPageAlumnos.Controls.Add(this.lblApelidoPaterno);
            this.tabPageAlumnos.Controls.Add(this.lblNombre);
            this.tabPageAlumnos.Location = new System.Drawing.Point(4, 25);
            this.tabPageAlumnos.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPageAlumnos.Name = "tabPageAlumnos";
            this.tabPageAlumnos.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPageAlumnos.Size = new System.Drawing.Size(707, 282);
            this.tabPageAlumnos.TabIndex = 0;
            this.tabPageAlumnos.Text = "Alumnos";
            this.tabPageAlumnos.UseVisualStyleBackColor = true;
            // 
            // txtBoxCarrera
            // 
            this.txtBoxCarrera.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxCarrera.Location = new System.Drawing.Point(184, 210);
            this.txtBoxCarrera.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtBoxCarrera.MaxLength = 50;
            this.txtBoxCarrera.Name = "txtBoxCarrera";
            this.txtBoxCarrera.Size = new System.Drawing.Size(319, 26);
            this.txtBoxCarrera.TabIndex = 15;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(102, 213);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 20);
            this.label4.TabIndex = 14;
            this.label4.Text = "Carrera";
            // 
            // txtBoxCURP
            // 
            this.txtBoxCURP.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxCURP.Location = new System.Drawing.Point(184, 172);
            this.txtBoxCURP.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtBoxCURP.MaxLength = 50;
            this.txtBoxCURP.Name = "txtBoxCURP";
            this.txtBoxCURP.Size = new System.Drawing.Size(319, 26);
            this.txtBoxCURP.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(112, 174);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 20);
            this.label3.TabIndex = 10;
            this.label3.Text = "CURP";
            // 
            // btnAgregar
            // 
            this.btnAgregar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnAgregar.Location = new System.Drawing.Point(528, 28);
            this.btnAgregar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(145, 63);
            this.btnAgregar.TabIndex = 3;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.UseVisualStyleBackColor = true;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // btn_Clear
            // 
            this.btn_Clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btn_Clear.Location = new System.Drawing.Point(528, 111);
            this.btn_Clear.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Clear.Name = "btn_Clear";
            this.btn_Clear.Size = new System.Drawing.Size(145, 63);
            this.btn_Clear.TabIndex = 4;
            this.btn_Clear.Text = "Limpiar";
            this.btn_Clear.UseVisualStyleBackColor = true;
            this.btn_Clear.Click += new System.EventHandler(this.btn_Clear_Click);
            // 
            // txtBoxTelefono
            // 
            this.txtBoxTelefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxTelefono.Location = new System.Drawing.Point(184, 138);
            this.txtBoxTelefono.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtBoxTelefono.MaxLength = 10;
            this.txtBoxTelefono.Name = "txtBoxTelefono";
            this.txtBoxTelefono.Size = new System.Drawing.Size(319, 26);
            this.txtBoxTelefono.TabIndex = 9;
            // 
            // txtBoxApellidoMaterno
            // 
            this.txtBoxApellidoMaterno.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxApellidoMaterno.Location = new System.Drawing.Point(184, 106);
            this.txtBoxApellidoMaterno.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtBoxApellidoMaterno.MaxLength = 50;
            this.txtBoxApellidoMaterno.Name = "txtBoxApellidoMaterno";
            this.txtBoxApellidoMaterno.Size = new System.Drawing.Size(319, 26);
            this.txtBoxApellidoMaterno.TabIndex = 8;
            // 
            // txtBoxApellidoPaterno
            // 
            this.txtBoxApellidoPaterno.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxApellidoPaterno.Location = new System.Drawing.Point(184, 74);
            this.txtBoxApellidoPaterno.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtBoxApellidoPaterno.MaxLength = 50;
            this.txtBoxApellidoPaterno.Name = "txtBoxApellidoPaterno";
            this.txtBoxApellidoPaterno.Size = new System.Drawing.Size(319, 26);
            this.txtBoxApellidoPaterno.TabIndex = 7;
            // 
            // txtBoxNombre
            // 
            this.txtBoxNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxNombre.Location = new System.Drawing.Point(184, 42);
            this.txtBoxNombre.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtBoxNombre.MaxLength = 50;
            this.txtBoxNombre.Name = "txtBoxNombre";
            this.txtBoxNombre.Size = new System.Drawing.Size(319, 26);
            this.txtBoxNombre.TabIndex = 6;
            // 
            // lblTelefono
            // 
            this.lblTelefono.AutoSize = true;
            this.lblTelefono.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTelefono.Location = new System.Drawing.Point(92, 140);
            this.lblTelefono.Name = "lblTelefono";
            this.lblTelefono.Size = new System.Drawing.Size(73, 20);
            this.lblTelefono.TabIndex = 4;
            this.lblTelefono.Text = "Telefono";
            // 
            // lblApellidoMaterno
            // 
            this.lblApellidoMaterno.AutoSize = true;
            this.lblApellidoMaterno.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApellidoMaterno.Location = new System.Drawing.Point(29, 108);
            this.lblApellidoMaterno.Name = "lblApellidoMaterno";
            this.lblApellidoMaterno.Size = new System.Drawing.Size(134, 20);
            this.lblApellidoMaterno.TabIndex = 3;
            this.lblApellidoMaterno.Text = "Apellido Materno";
            // 
            // lblApelidoPaterno
            // 
            this.lblApelidoPaterno.AutoSize = true;
            this.lblApelidoPaterno.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApelidoPaterno.Location = new System.Drawing.Point(33, 76);
            this.lblApelidoPaterno.Name = "lblApelidoPaterno";
            this.lblApelidoPaterno.Size = new System.Drawing.Size(131, 20);
            this.lblApelidoPaterno.TabIndex = 2;
            this.lblApelidoPaterno.Text = "Apellido Paterno";
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre.Location = new System.Drawing.Point(99, 44);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(68, 20);
            this.lblNombre.TabIndex = 1;
            this.lblNombre.Text = "Nombre";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.comboBoxTipoUser);
            this.tabPage2.Controls.Add(this.btnAgregarMaestros);
            this.tabPage2.Controls.Add(this.btnLimpiarMaestros);
            this.tabPage2.Controls.Add(this.txtBoxPassword);
            this.tabPage2.Controls.Add(this.txtBoxUsername);
            this.tabPage2.Controls.Add(this.lblTipoUser);
            this.tabPage2.Controls.Add(this.lblPassword);
            this.tabPage2.Controls.Add(this.lblUser);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage2.Size = new System.Drawing.Size(707, 282);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Maestros";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // comboBoxTipoUser
            // 
            this.comboBoxTipoUser.FormattingEnabled = true;
            this.comboBoxTipoUser.Items.AddRange(new object[] {
            "Administrador",
            "Maestro"});
            this.comboBoxTipoUser.Location = new System.Drawing.Point(169, 122);
            this.comboBoxTipoUser.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBoxTipoUser.Name = "comboBoxTipoUser";
            this.comboBoxTipoUser.Size = new System.Drawing.Size(319, 24);
            this.comboBoxTipoUser.TabIndex = 17;
            // 
            // btnAgregarMaestros
            // 
            this.btnAgregarMaestros.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnAgregarMaestros.Location = new System.Drawing.Point(536, 26);
            this.btnAgregarMaestros.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAgregarMaestros.Name = "btnAgregarMaestros";
            this.btnAgregarMaestros.Size = new System.Drawing.Size(145, 63);
            this.btnAgregarMaestros.TabIndex = 15;
            this.btnAgregarMaestros.Text = "Agregar";
            this.btnAgregarMaestros.UseVisualStyleBackColor = true;
            this.btnAgregarMaestros.Click += new System.EventHandler(this.btnAgregarMaestros_Click);
            // 
            // btnLimpiarMaestros
            // 
            this.btnLimpiarMaestros.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.btnLimpiarMaestros.Location = new System.Drawing.Point(536, 108);
            this.btnLimpiarMaestros.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLimpiarMaestros.Name = "btnLimpiarMaestros";
            this.btnLimpiarMaestros.Size = new System.Drawing.Size(145, 63);
            this.btnLimpiarMaestros.TabIndex = 16;
            this.btnLimpiarMaestros.Text = "Limpiar";
            this.btnLimpiarMaestros.UseVisualStyleBackColor = true;
            // 
            // txtBoxPassword
            // 
            this.txtBoxPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxPassword.Location = new System.Drawing.Point(169, 87);
            this.txtBoxPassword.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtBoxPassword.MaxLength = 50;
            this.txtBoxPassword.Name = "txtBoxPassword";
            this.txtBoxPassword.Size = new System.Drawing.Size(319, 26);
            this.txtBoxPassword.TabIndex = 13;
            // 
            // txtBoxUsername
            // 
            this.txtBoxUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBoxUsername.Location = new System.Drawing.Point(169, 55);
            this.txtBoxUsername.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtBoxUsername.MaxLength = 50;
            this.txtBoxUsername.Name = "txtBoxUsername";
            this.txtBoxUsername.Size = new System.Drawing.Size(319, 26);
            this.txtBoxUsername.TabIndex = 12;
            // 
            // lblTipoUser
            // 
            this.lblTipoUser.AutoSize = true;
            this.lblTipoUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipoUser.Location = new System.Drawing.Point(100, 122);
            this.lblTipoUser.Name = "lblTipoUser";
            this.lblTipoUser.Size = new System.Drawing.Size(52, 20);
            this.lblTipoUser.TabIndex = 11;
            this.lblTipoUser.Text = "Labor";
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPassword.Location = new System.Drawing.Point(53, 90);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(95, 20);
            this.lblPassword.TabIndex = 10;
            this.lblPassword.Text = "Contraseña";
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUser.Location = new System.Drawing.Point(84, 58);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(67, 20);
            this.lblUser.TabIndex = 9;
            this.lblUser.Text = "Usuario";
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage1);
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Controls.Add(this.tabPage9);
            this.tabControl2.Location = new System.Drawing.Point(0, 1);
            this.tabControl2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(700, 351);
            this.tabControl2.TabIndex = 2;
            this.tabControl2.Click += new System.EventHandler(this.FormAdministrador_Load);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tabControl1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Size = new System.Drawing.Size(692, 322);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Registro";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.tabControl3);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage3.Size = new System.Drawing.Size(692, 322);
            this.tabPage3.TabIndex = 1;
            this.tabPage3.Text = "Visualizar";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage6);
            this.tabControl3.Controls.Add(this.tabPage7);
            this.tabControl3.Controls.Add(this.tabPage10);
            this.tabControl3.Location = new System.Drawing.Point(3, 2);
            this.tabControl3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(685, 249);
            this.tabControl3.TabIndex = 2;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.dataGridAlumnos);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage6.Size = new System.Drawing.Size(677, 220);
            this.tabPage6.TabIndex = 0;
            this.tabPage6.Text = "Alumnos";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // dataGridAlumnos
            // 
            this.dataGridAlumnos.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.dataGridAlumnos.AllowUserToAddRows = false;
            this.dataGridAlumnos.AllowUserToDeleteRows = false;
            this.dataGridAlumnos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridAlumnos.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.dataGridAlumnos.Location = new System.Drawing.Point(5, 5);
            this.dataGridAlumnos.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridAlumnos.Name = "dataGridAlumnos";
            this.dataGridAlumnos.ReadOnly = true;
            this.dataGridAlumnos.RowHeadersWidth = 62;
            this.dataGridAlumnos.RowTemplate.Height = 28;
            this.dataGridAlumnos.Size = new System.Drawing.Size(668, 213);
            this.dataGridAlumnos.TabIndex = 0;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.dataGridMaestros);
            this.tabPage7.Location = new System.Drawing.Point(4, 25);
            this.tabPage7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage7.Size = new System.Drawing.Size(677, 220);
            this.tabPage7.TabIndex = 1;
            this.tabPage7.Text = "Maestros";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // dataGridMaestros
            // 
            this.dataGridMaestros.AllowUserToAddRows = false;
            this.dataGridMaestros.AllowUserToDeleteRows = false;
            this.dataGridMaestros.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridMaestros.Location = new System.Drawing.Point(5, 5);
            this.dataGridMaestros.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridMaestros.Name = "dataGridMaestros";
            this.dataGridMaestros.ReadOnly = true;
            this.dataGridMaestros.RowHeadersWidth = 62;
            this.dataGridMaestros.RowTemplate.Height = 28;
            this.dataGridMaestros.Size = new System.Drawing.Size(668, 213);
            this.dataGridMaestros.TabIndex = 1;
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.dgv2);
            this.tabPage10.Location = new System.Drawing.Point(4, 25);
            this.tabPage10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage10.Size = new System.Drawing.Size(677, 220);
            this.tabPage10.TabIndex = 2;
            this.tabPage10.Text = "Alumnos Becados";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // dgv2
            // 
            this.dgv2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv2.Location = new System.Drawing.Point(6, 6);
            this.dgv2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgv2.Name = "dgv2";
            this.dgv2.RowHeadersWidth = 51;
            this.dgv2.Size = new System.Drawing.Size(668, 210);
            this.dgv2.TabIndex = 1;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.label2);
            this.tabPage4.Controls.Add(this.nuevoValor_Tbx);
            this.tabPage4.Controls.Add(this.NoControlParaEditar_Tbx);
            this.tabPage4.Controls.Add(this.label1);
            this.tabPage4.Controls.Add(this.Editar_datos_Cbx);
            this.tabPage4.Controls.Add(this.Editar_Lbl_);
            this.tabPage4.Controls.Add(this.Editar_Btn);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(692, 322);
            this.tabPage4.TabIndex = 2;
            this.tabPage4.Text = "Editar";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(188, 142);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(174, 31);
            this.label2.TabIndex = 7;
            this.label2.Text = "Nuevo valor: ";
            // 
            // nuevoValor_Tbx
            // 
            this.nuevoValor_Tbx.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nuevoValor_Tbx.Location = new System.Drawing.Point(376, 145);
            this.nuevoValor_Tbx.Name = "nuevoValor_Tbx";
            this.nuevoValor_Tbx.Size = new System.Drawing.Size(100, 30);
            this.nuevoValor_Tbx.TabIndex = 6;
            // 
            // NoControlParaEditar_Tbx
            // 
            this.NoControlParaEditar_Tbx.Location = new System.Drawing.Point(536, 76);
            this.NoControlParaEditar_Tbx.Name = "NoControlParaEditar_Tbx";
            this.NoControlParaEditar_Tbx.Size = new System.Drawing.Size(100, 22);
            this.NoControlParaEditar_Tbx.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(276, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(254, 29);
            this.label1.TabIndex = 3;
            this.label1.Text = "NoControl del alumno:";
            // 
            // Editar_datos_Cbx
            // 
            this.Editar_datos_Cbx.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Editar_datos_Cbx.FormattingEnabled = true;
            this.Editar_datos_Cbx.Items.AddRange(new object[] {
            "nombre",
            "apellidoPaterno",
            "apellidoMaterno",
            "curp",
            "telefono",
            "id_carrera",
            "id_beca"});
            this.Editar_datos_Cbx.Location = new System.Drawing.Point(45, 145);
            this.Editar_datos_Cbx.Name = "Editar_datos_Cbx";
            this.Editar_datos_Cbx.Size = new System.Drawing.Size(121, 33);
            this.Editar_datos_Cbx.TabIndex = 2;
            // 
            // Editar_Lbl_
            // 
            this.Editar_Lbl_.AutoSize = true;
            this.Editar_Lbl_.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Editar_Lbl_.Location = new System.Drawing.Point(40, 31);
            this.Editar_Lbl_.Name = "Editar_Lbl_";
            this.Editar_Lbl_.Size = new System.Drawing.Size(232, 29);
            this.Editar_Lbl_.TabIndex = 1;
            this.Editar_Lbl_.Text = "EDITOR DE DATOS";
            // 
            // Editar_Btn
            // 
            this.Editar_Btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Editar_Btn.Location = new System.Drawing.Point(520, 195);
            this.Editar_Btn.Name = "Editar_Btn";
            this.Editar_Btn.Size = new System.Drawing.Size(116, 61);
            this.Editar_Btn.TabIndex = 0;
            this.Editar_Btn.Text = "Editar";
            this.Editar_Btn.UseVisualStyleBackColor = true;
            this.Editar_Btn.Click += new System.EventHandler(this.Editar_Btn_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.Eliminar_Btn);
            this.tabPage5.Controls.Add(this.Titulo_Lbl);
            this.tabPage5.Controls.Add(this.noControl_Lbl);
            this.tabPage5.Controls.Add(this.noControl_Tbx);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(692, 322);
            this.tabPage5.TabIndex = 3;
            this.tabPage5.Text = "Eliminar";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // Eliminar_Btn
            // 
            this.Eliminar_Btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Eliminar_Btn.Location = new System.Drawing.Point(440, 62);
            this.Eliminar_Btn.Name = "Eliminar_Btn";
            this.Eliminar_Btn.Size = new System.Drawing.Size(204, 55);
            this.Eliminar_Btn.TabIndex = 3;
            this.Eliminar_Btn.Text = "ELIMINAR";
            this.Eliminar_Btn.UseVisualStyleBackColor = true;
            this.Eliminar_Btn.Click += new System.EventHandler(this.Eliminar_Btn_Click);
            // 
            // Titulo_Lbl
            // 
            this.Titulo_Lbl.AutoSize = true;
            this.Titulo_Lbl.Font = new System.Drawing.Font("Arial", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Titulo_Lbl.Location = new System.Drawing.Point(35, 51);
            this.Titulo_Lbl.Name = "Titulo_Lbl";
            this.Titulo_Lbl.Size = new System.Drawing.Size(316, 32);
            this.Titulo_Lbl.TabIndex = 2;
            this.Titulo_Lbl.Text = "Dar de baja un ALUMNO";
            // 
            // noControl_Lbl
            // 
            this.noControl_Lbl.AutoSize = true;
            this.noControl_Lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.noControl_Lbl.Location = new System.Drawing.Point(54, 103);
            this.noControl_Lbl.Name = "noControl_Lbl";
            this.noControl_Lbl.Size = new System.Drawing.Size(106, 25);
            this.noControl_Lbl.TabIndex = 1;
            this.noControl_Lbl.Text = "NoControl:";
            // 
            // noControl_Tbx
            // 
            this.noControl_Tbx.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.noControl_Tbx.Location = new System.Drawing.Point(185, 100);
            this.noControl_Tbx.Name = "noControl_Tbx";
            this.noControl_Tbx.Size = new System.Drawing.Size(140, 30);
            this.noControl_Tbx.TabIndex = 0;
            this.noControl_Tbx.Text = "Insertar ";
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.dgv3);
            this.tabPage9.Location = new System.Drawing.Point(4, 25);
            this.tabPage9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.tabPage9.Size = new System.Drawing.Size(692, 322);
            this.tabPage9.TabIndex = 5;
            this.tabPage9.Text = "Vistas";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // dgv3
            // 
            this.dgv3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv3.Location = new System.Drawing.Point(11, 7);
            this.dgv3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgv3.Name = "dgv3";
            this.dgv3.RowHeadersWidth = 51;
            this.dgv3.Size = new System.Drawing.Size(679, 318);
            this.dgv3.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(178, 364);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 31);
            this.label5.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(11, 364);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(156, 31);
            this.label6.TabIndex = 4;
            this.label6.Text = "Bienvenido:";
            // 
            // FormAdministrador
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(711, 400);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tabControl2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FormAdministrador";
            this.Text = "Menu principal";
            this.Load += new System.EventHandler(this.FormAdministrador_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPageAlumnos.ResumeLayout(false);
            this.tabPageAlumnos.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabControl2.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridAlumnos)).EndInit();
            this.tabPage7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridMaestros)).EndInit();
            this.tabPage10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPageAlumnos;
        private System.Windows.Forms.Label lblTelefono;
        private System.Windows.Forms.Label lblApellidoMaterno;
        private System.Windows.Forms.Label lblApelidoPaterno;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox txtBoxTelefono;
        private System.Windows.Forms.TextBox txtBoxApellidoMaterno;
        private System.Windows.Forms.TextBox txtBoxApellidoPaterno;
        private System.Windows.Forms.TextBox txtBoxNombre;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Button btn_Clear;
        private System.Windows.Forms.Button btnAgregarMaestros;
        private System.Windows.Forms.Button btnLimpiarMaestros;
        private System.Windows.Forms.TextBox txtBoxPassword;
        private System.Windows.Forms.TextBox txtBoxUsername;
        private System.Windows.Forms.Label lblTipoUser;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.ComboBox comboBoxTipoUser;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.DataGridView dataGridAlumnos;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.DataGridView dataGridMaestros;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.DataGridView dgv3;
        private System.Windows.Forms.TextBox noControl_Tbx;
        private System.Windows.Forms.Label noControl_Lbl;
        private System.Windows.Forms.Label Titulo_Lbl;
        private System.Windows.Forms.Button Editar_Btn;
        private System.Windows.Forms.Button Eliminar_Btn;
        private System.Windows.Forms.ComboBox Editar_datos_Cbx;
        private System.Windows.Forms.Label Editar_Lbl_;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox nuevoValor_Tbx;
        private System.Windows.Forms.TextBox NoControlParaEditar_Tbx;
        private System.Windows.Forms.TextBox txtBoxCURP;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtBoxCarrera;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.DataGridView dgv2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}
